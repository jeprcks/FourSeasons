<?php

declare(strict_types=1);

namespace App\Models;

use App\Core\Model;

class SchoolProgram extends Model
{
    protected string $table = 'school_programs';
}
