<?php

declare(strict_types=1);

namespace App\Models;

use App\Core\Model;

class Event extends Model
{
    protected string $table = 'events';
}
