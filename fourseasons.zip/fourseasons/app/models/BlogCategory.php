<?php

declare(strict_types=1);

namespace App\Models;

use App\Core\Model;

class BlogCategory extends Model
{
    protected string $table = 'blog_categories';
}
